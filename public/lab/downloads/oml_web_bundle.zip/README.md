# OML updated notebook and study results

Source: OML_project_update.zip, 24 November 2026. This package contains the updated
seven-step heuristic and the unchanged two-stage MILP model, one master notebook
for both surveys, input CSVs, data-generation code, and all 48 supplied plans.

## Run the notebook

Open OML_elective_timetabling_master/OML_master.ipynb with its working directory
set to that same folder. Set SURVEY in Section 1.2 to survey_9_to_10.5_credits or
survey_5_to_9_credits, then run all cells. OML_master.py is the notebook's code
cells concatenated in order. Python 3, pandas, NumPy, SciPy >= 1.15, matplotlib,
and openpyxl are required; highspy is optional.

The supplied solver caches retain the original 20-minute limit per stage. The
master notebook loads those caches and reruns the updated heuristic. Its cache
filenames do not fingerprint changed inputs. Delete incompatible cache files
before rerunning the notebook with different data/settings. The web app uses
separate run history with complete inputs and fingerprints.

## What is included

- oml_project.json: 69 courses, 1,184 occupied slots, seven same-content groups,
  two surveys of 416 synthetic students, and 48 scenario-method results.
- validation.json: checks of every supplied allocation and move against inputs,
  plus agreement with workbook summaries. No full optimization was rerun while
  producing this package.
- OML_elective_timetabling_master: updated notebook, Python code, both surveys'
  CSVs, build_survey.py and build_data.py reference scripts, sanitized workbooks,
  and primitive-only solver/heuristic caches.
- supplemental/solver_30min_summary.json: the separate 30-minute-per-stage
  rerun's summary only. No complete plan was supplied for that rerun, so it is
  not a loadable result and is not included among the 48 main study results.
- provenance.json: hashes of the source files used to build this package.

Faculty names and raw timetable files are excluded. A blank instructors column
is retained in downloaded units.csv and workbook reports so notebook reporting
cells still work. The reference build_data.py needs original raw timetables,
which are not distributed here; sanitized model-ready CSVs are included.
Its hard-coded faculty-name fields are blank. Model and heuristic functions in
the notebook and OML_master.py are otherwise unchanged. Notebook outputs are
cleared. All student IDs S001-S416 are synthetic, not actual registration data.

BaB capacity remains 80, following the supplied CSV assumption: "default 80
(outline says TBD)". Change the actual course capacity input to test another cap.

## Interpreting results

A time-limit solver result is a feasible incumbent, not a proven optimum.
Step 1 reports its solve-time weighted objective and bound. Final shortfall and
asked-course counts may improve during Step 2 and cleanup. Step 2's credit bound
is conditional on Step 1 locks. The 30-minute rerun does not replace the supplied
20-minute main results.

Moves identify original sessions to vacate. Replacement slots are not assigned
by this model. Protected block slots never move; the allowance counts all
occupied slots before limiting movable class sessions. Heuristic quality can
differ from solver quality; saved results and fresh browser runs are distinct.
