"""Generate the synthetic PGP pre-term demand survey (Term VI, 2026-27).

Rules (agreed with the group):
- 416 students, each listing only PGP sections (56 in the Term VI timetable).
- No ranking: a list is just the set of courses a student wants.
- Each list adds up to between 9 and 10.5 credits.
- Every section is equally likely to be picked.

Method: each student gets a random target between 9 and 10.5 credits (steps of 0.25).
The 56 sections are shuffled and taken in that order. The list stops once it reaches the
target, or just before a course that would push it above 10.5 credits. Taking courses
strictly in shuffled order (never skipping ahead to find a small course that fits) keeps
every section equally likely to be listed, whatever its credits.
"""
from pathlib import Path

import numpy as np
import pandas as pd

TIMETABLE_FILE = Path("data/raw/2026-27_PGP_II_Term_VI_Timetable.xls")
OUT_DIR = Path("data")
N_STUDENTS = 416
MIN_LISTED, MAX_LISTED = 9.0, 10.5
CREDIT_STEP = 0.25
SEED = 2026

# ---- PGP sections and credits, from the timetable's Course Details sheet ----
details = pd.read_excel(TIMETABLE_FILE, sheet_name="Course Details", header=2, engine="calamine")
details = details[pd.to_numeric(details["No"], errors="coerce").notna()]
courses = (details.rename(columns={"Course Acronym": "course", "Course Name": "course_name", "Credit": "credits"})
           [["course", "course_name", "credits"]].reset_index(drop=True))
courses["course_name"] = courses["course_name"].str.strip()
courses["credits"] = courses["credits"].astype(float)
assert len(courses) == 56, len(courses)

codes = courses["course"].to_numpy()
credits = courses["credits"].to_numpy()
targets = np.arange(MIN_LISTED, MAX_LISTED + 1e-9, CREDIT_STEP)

# ---- Draw one list per student ----
rng = np.random.default_rng(SEED)
rows = []
for k in range(1, N_STUDENTS + 1):
    target = rng.choice(targets)
    picked, total = [], 0.0
    for j in rng.permutation(len(codes)):
        if total + credits[j] > MAX_LISTED + 1e-9:
            break
        picked.append(j)
        total += credits[j]
        if total >= target - 1e-9:
            break
    student = f"S{k:03d}"
    for j in sorted(picked, key=lambda j: codes[j].lower()):     # alphabetical: no ranking implied
        rows.append({"student_id": student, "course": codes[j],
                     "course_name": courses.at[j, "course_name"], "credits": credits[j]})

survey = pd.DataFrame(rows)

# ---- Views and checks ----
by_student = (survey.groupby("student_id")
              .agg(courses_listed=("course", "size"), total_credits=("credits", "sum"),
                   courses=("course", lambda s: ", ".join(s)))
              .reset_index())

demand = (survey.groupby("course").size().rename("students_listing")
          .reindex(codes).fillna(0).astype(int).reset_index())
demand = courses.merge(demand, on="course")

assert survey.groupby("student_id")["course"].apply(lambda s: s.is_unique).all()
assert by_student["total_credits"].between(MIN_LISTED, MAX_LISTED).all()
assert by_student["student_id"].nunique() == N_STUDENTS

OUT_DIR.mkdir(exist_ok=True)
survey.to_csv(OUT_DIR / "pgp_preference_survey.csv", index=False)
by_student.to_csv(OUT_DIR / "pgp_preference_survey_by_student.csv", index=False)
demand.to_csv(OUT_DIR / "pgp_course_demand.csv", index=False)

pairs = [("AMD(A)", "AMD(B)"), ("NS(A)", "NS(B)"), ("MEnB(A)", "MEnB(B)"), ("MVE(A)", "MVE(B)")]
both = {f"{a}+{b}": int(survey.groupby("student_id")["course"].apply(lambda s: {a, b} <= set(s)).sum())
        for a, b in pairs}

print(f"Students: {by_student.shape[0]},  rows: {len(survey)}")
print("Credits listed per student:", by_student["total_credits"].value_counts().sort_index().to_dict())
print(f"Courses per student: min {by_student['courses_listed'].min()}, "
      f"mean {by_student['courses_listed'].mean():.2f}, max {by_student['courses_listed'].max()}")
print(f"Students listing a course: min {demand['students_listing'].min()}, "
      f"mean {demand['students_listing'].mean():.1f}, max {demand['students_listing'].max()}")
print("Students listing both sections of a course:", both)
print("Mean students listing, by credit:", demand.groupby("credits")["students_listing"].mean().round(1).to_dict())
