"""Build the model's data files from the three Term VI timetables.

Outputs (in data/):
  units.csv               one row per biddable unit (69): credits, seat cap, sessions, group, flags
  sessions.csv            one row per unit, date and slot (classes plus full-day blocks)
  same_content_groups.csv units that teach the same content (a student may hold at most one)
  parameters.csv          term rules and model settings the notebook reads

Seat caps come from the course outlines (PGP number, else total, else 80 for PGP; FABM PGP
number, else 10) and from the PGPX sheet "Open to Other Programmes". They are typed in below
with their source, because the outlines are PDFs with inconsistent tables.
"""
from pathlib import Path
import re

import pandas as pd

RAW = Path("data/raw")
OUT = Path("data")
PGP_FILE = RAW / "2026-27_PGP_II_Term_VI_Timetable.xls"
FABM_FILE = RAW / "2026-27_PGP-FABM_II_Term_VI_Timetable.xls"
PGPX_FILE = RAW / "PGPX_2026-27_Term-6_Time_Table.xlsx"

SLOTS = ["0845-1000", "1020-1135", "1155-1310", "1430-1545", "1605-1720", "1740-1855", "1915-2030"]
MONTH_YEAR = {"Dec": 2026, "Jan": 2027, "Feb": 2027, "Mar": 2027}

# ---------------------------------------------------------------------------
# Seat caps (PGP seats) with sources
# ---------------------------------------------------------------------------
PGP_CAPS = {  # unit: (cap, source)
    "ABS": (30, "outline PGP"), "AFD": (40, "outline PGP"), "AMD(A)": (40, "outline PGP, per section"),
    "AMD(B)": (40, "outline PGP, per section"), "BaB": (80, "default 80 (outline says TBD)"),
    "BLL": (80, "outline PGP"), "CAC": (80, "default 80 (no table)"), "CFI": (50, "outline PGP+Exchange"),
    "DBMS": (25, "outline PGP"), "DMDP": (80, "default 80 (no table)"), "EC": (80, "default 80 (no table)"),
    "EDPG": (50, "outline PGP"), "EFQ": (20, "outline student limit PGP"), "EHM": (50, "outline PGP"),
    "EIAI": (20, "outline PGP"), "EoS": (50, "outline PGP"), "ERA": (80, "default 80 (table blank)"),
    "GAIM": (25, "outline PGP"), "GDPP": (30, "outline PGP"), "HE": (80, "default 80 (no table)"),
    "HHF": (40, "outline PGP"), "HITCH": (80, "default 80 (no number)"), "HRG": (30, "outline PGP"),
    "ICSI": (80, "default 80 (no table)"), "InB": (30, "outline PGP"), "INL": (47, "outline PGP"),
    "ITES": (80, "default 80 (no table)"), "ITS": (30, "outline class size"), "LOE": (50, "outline PGP"),
    "MAP": (100, "outline PGP"), "MCVD": (80, "default 80 (no table)"),
    "MEnB(A)": (80, "default 80 (no number), per section"), "MEnB(B)": (80, "default 80 (no number), per section"),
    "MHCP": (80, "default 80 (no table)"), "MiM": (50, "outline PGP"), "MktC": (80, "default 80 (table blank)"),
    "MPSCDA": (50, "outline PGP"), "MSLBET": (50, "outline total"), "MVE(A)": (48, "outline PGP, per section"),
    "MVE(B)": (48, "outline PGP, per section"), "NS(A)": (50, "outline total, per section"),
    "NS(B)": (50, "outline total, per section"), "OMF": (30, "outline PGP"), "PAAIB": (45, "outline PGP"),
    "PGA": (30, "outline class size"), "PPCA": (40, "outline PGP"), "PPI": (48, "outline PGP"),
    "PTfD": (25, "outline PGP"), "RBLCA": (80, "outline PGP"), "RMBA": (80, "default 80 (no table)"),
    "SE": (40, "outline PGP"), "SR": (80, "default 80 (no table)"), "SST": (80, "default 80 (no table)"),
    "UBG": (80, "default 80 (no table)"), "URBAN": (80, "default 80 (outline says Open)"),
    "WEBGP": (80, "default 80 (table blank)"),
}
FABM_UNITS = {  # code: (name, credits, instructors, cap, source)
    "AbL": ("Agribusiness Leadership", 0.50, "", 50, "outline PGP"),
    "IBDI": ("Commodities Markets: Implications for Business Decisions and Investments", 0.75,
             "", 30, "outline PGP"),
    "SMAP": ("Strategic Management & Consulting For Agro-Food Projects", 1.00, "", 20, "outline PGP"),
    "AFOM": ("Agriculture Futures and Options Markets", 0.75, "", 10, "outline PGP"),
    "MACA": ("Managing Agricultural Carbon Assets", 0.50, "", 10, "outline PGP"),
    "MAFT": ("Managing Agri-Food Trade", 0.50, "", 5, "outline PGP"),
}
PGPX_UNITS = {  # code: (name, credits, instructors, cap, source)
    "AFP": ("Agriculture and Food Policy", 0.50, "", 10, "PGPX sheet: PGP-10"),
    "MCF": ("Managing Contract Farming", 1.00, "", 10, "PGPX sheet: PGP-10"),
    "EHM": ("Essentials of Health-tech Management", 0.75, "",
            50, "PGPX sheet: PGP-50"),
    "InB": ("International Banking", 0.50, "", 5, "PGPX sheet: PGP-5"),
    "NL-A": ("Negotiation Lab (Sec-A)", 0.50, "", 5, "PGPX sheet: PGP-5"),
    "NL-B": ("Negotiation Lab (Sec-B)", 0.50, "", 5, "PGPX sheet: PGP-5"),
    "SY": ("Shodh Yatra: Learning from the grassroots (Dec 17-23, off campus)", 1.25,
           "", 5, "PGPX sheet: PGP 5"),
}
GROUPS = {
    "AMD": ["AMD(A)", "AMD(B)"], "NS": ["NS(A)", "NS(B)"], "MEnB": ["MEnB(A)", "MEnB(B)"],
    "MVE": ["MVE(A)", "MVE(B)"], "EHM": ["EHM", "EHM_PGPX"], "InB": ["InB", "InB_PGPX"],
    "NL": ["NL-A_PGPX", "NL-B_PGPX"],
}
BLOCKS = [  # unit_id, first date, last date, note
    ("SY_PGPX", "2026-12-17", "2026-12-23", "Shodh Yatra off-campus block"),
    ("PTfD", "2026-12-04", "2026-12-08", "PTfD workshop block"),
    ("ITS", "2026-12-31", "2026-12-31", "ITS field visit"),
]


def grid_sessions(path, programme, keep):
    """Read a PGP-style grid (Pre and Post sheets) into (unit, date, slot) rows."""
    rows = []
    for sheet in ("Pre", "Post"):
        df = pd.read_excel(path, sheet_name=sheet, header=None, engine="calamine")
        hdr = df.index[df[0].astype(str).str.strip().eq("Month")][0]
        body = df.loc[hdr + 1:].copy()
        body = body[body[1].notna()]
        body[0] = body[0].ffill()
        for _, r in body.iterrows():
            date = pd.Timestamp(f"{int(r[1])} {r[0]} {MONTH_YEAR[str(r[0]).strip()]}")
            for k, slot in enumerate(SLOTS):
                cell = r[3 + k]
                if pd.isna(cell):
                    continue
                for tok in re.split(r"[/\n]", str(cell)):
                    tok = re.sub(r"\s+\d+$", "", tok.strip())        # 'MACA 01' -> 'MACA'
                    if tok in keep:
                        rows.append((keep[tok], programme, date, slot, "class"))
    return rows


def pgpx_sessions(path, keep):
    df = pd.read_excel(path, sheet_name="Term-6_TT_PGPX_2026-27", header=None, engine="calamine")
    rows = []
    for _, r in df.iloc[2:].iterrows():
        date = pd.to_datetime(r[1], errors="coerce")
        if pd.isna(date):
            continue
        for k, slot in enumerate(SLOTS):
            cell = r[3 + k]
            if pd.isna(cell):
                continue
            for tok in str(cell).split("/"):
                tok = tok.strip()
                if tok in keep:
                    rows.append((keep[tok], "PGPX", date, slot, "class"))
    return rows


# ---------------------------------------------------------------------------
# Units
# ---------------------------------------------------------------------------
details = pd.read_excel(PGP_FILE, sheet_name="Course Details", header=2, engine="calamine")
details = details[pd.to_numeric(details["No"], errors="coerce").notna()]
units = []
for _, r in details.iterrows():
    code = str(r["Course Acronym"]).strip()
    cap, src = PGP_CAPS[code]
    units.append({"unit_id": code, "course_code": code, "programme": "PGP", "area": str(r["Area"]).strip(),
                  "course_name": str(r["Course Name"]).strip(), "credits": float(r["Credit"]),
                  "instructors": str(r["Instructor(s)"]).strip(), "seat_cap": cap, "seat_cap_source": src})
for prog, table in (("FABM", FABM_UNITS), ("PGPX", PGPX_UNITS)):
    for code, (name, cr, ins, cap, src) in table.items():
        units.append({"unit_id": f"{code}_{prog}", "course_code": code, "programme": prog, "area": "",
                      "course_name": name, "credits": cr, "instructors": ins, "seat_cap": cap, "seat_cap_source": src})
units = pd.DataFrame(units)
assert len(units) == 69 and units["unit_id"].is_unique

# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------
pgp_keep = {c: c for c in units.loc[units.programme == "PGP", "unit_id"]}
fabm_keep = {c: f"{c}_FABM" for c in FABM_UNITS}
pgpx_keep = {c: f"{c}_PGPX" for c in PGPX_UNITS}
rows = (grid_sessions(PGP_FILE, "PGP", pgp_keep) + grid_sessions(FABM_FILE, "FABM", fabm_keep)
        + pgpx_sessions(PGPX_FILE, pgpx_keep))
prog_of = units.set_index("unit_id")["programme"].to_dict()
for unit, first, last, _ in BLOCKS:
    for d in pd.date_range(first, last):
        for slot in SLOTS:
            rows.append((unit, prog_of[unit], d, slot, "block"))
sessions = (pd.DataFrame(rows, columns=["unit_id", "programme", "date", "slot", "session_type"])
            .drop_duplicates(["unit_id", "date", "slot"])
            .sort_values(["date", "slot", "unit_id"]).reset_index(drop=True))
sessions["date"] = sessions["date"].dt.strftime("%Y-%m-%d")
sessions["day"] = pd.to_datetime(sessions["date"]).dt.strftime("%a")
sessions = sessions[["unit_id", "programme", "date", "day", "slot", "session_type"]]

# ---------------------------------------------------------------------------
# Unit flags and counts
# ---------------------------------------------------------------------------
cls = sessions[sessions.session_type == "class"].groupby("unit_id").size()
units["class_sessions"] = units["unit_id"].map(cls).fillna(0).astype(int)
units["sessions_expected_from_credits"] = (units["credits"] * 20).round().astype(int)
units["is_block"] = units["unit_id"].isin(["SY_PGPX", "PTfD"]).astype(int)
units["movable"] = 1 - units["is_block"]
units["in_survey"] = (units["programme"] == "PGP").astype(int)
units["is_pgpx_or_fabm"] = (units["programme"] != "PGP").astype(int)
grp = {u: g for g, members in GROUPS.items() for u in members}
units["same_content_group"] = units["unit_id"].map(grp).fillna("")
units = units[["unit_id", "course_code", "programme", "area", "course_name", "credits", "instructors",
               "seat_cap", "seat_cap_source", "class_sessions", "sessions_expected_from_credits",
               "is_block", "movable", "in_survey", "is_pgpx_or_fabm", "same_content_group"]]

groups = pd.DataFrame([(g, u) for g, members in GROUPS.items() for u in members], columns=["group_id", "unit_id"])
assert set(groups.unit_id) <= set(units.unit_id)

params = pd.DataFrame([
    ('N_STUDENTS', 416, 'Number of PGP students in the survey'),
    ('FLOORS', '5;6', 'Credit floors to run (each student should reach this many credits; penalised by LAMBDA)'),
    ('MAX_CREDITS', 9, 'Maximum credits a student can be allotted (hard)'),
    ('PGPX_FABM_VERSIONS', 'with;without', 'with = one PGPX or FABM course allowed on top of the survey list; without = survey list only'),
    ('MAX_PGPX_OR_FABM_UNITS', 1, "In the 'with' version: at most one PGPX or FABM unit per student (hard)"),
    ('THETA_VALUES', '0;0.10;0.20', "Flexibility values to run (share of a unit's occupied slots it may move)"),
    ('K_ROUNDING', 'floor(theta*n + 0.5)', 'Allowed moves per unit: nearest whole session, halves up; n counts all occupied slots'),
    ('LAMBDA', 1000, 'Penalty per credit of shortfall in Step 1'),
    ('SHOW_SOLVER_LOG', 'yes', 'yes = print HiGHS progress lines for full-model solves'),
    ('SURVEY_MIN_CREDITS', 5, 'Smallest total a demand survey list can have'),
    ('SURVEY_MAX_CREDITS', 9, 'Largest total a demand survey list can have'),
    ('SURVEY_TARGET_BAND', 0.5, "A list stops once its total is within this many credits of the student's random target"),
    ('SURVEY_SEED', 2026, 'Random seed used to generate the survey'),
    ('DEFAULT_CAP_PGP', 80, 'Seat cap used when a PGP outline gives no number'),
    ('DEFAULT_CAP_FABM', 10, 'Seat cap used when a FABM outline gives no PGP number'),
], columns=["parameter", "value", "description"])

units.to_csv(OUT / "units.csv", index=False)
sessions.to_csv(OUT / "sessions.csv", index=False)
groups.to_csv(OUT / "same_content_groups.csv", index=False)
params.to_csv(OUT / "parameters.csv", index=False)

print(units.groupby("programme").size().to_dict(), "units")
print(sessions.groupby("session_type").size().to_dict(), "session rows,", sessions.date.min(), "to", sessions.date.max())
odd = units[(units.class_sessions != units.sessions_expected_from_credits) & (units.is_block == 0)]
print("Units whose class count differs from 20 per credit:")
print(odd[["unit_id", "credits", "class_sessions", "sessions_expected_from_credits"]].to_string(index=False))
print("Units with no class sessions:", units.loc[units.class_sessions == 0, "unit_id"].tolist())
