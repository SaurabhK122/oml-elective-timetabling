import math
import pickle
import random
import time
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix

try:
    import highspy as hs                                  # HiGHS's own package: pip install highspy
    HighsSolver = hs.Highs
    print("Solver: HiGHS from the highspy package")
except ImportError:
    from scipy.optimize._highspy import _core as hs       # the same HiGHS, bundled inside SciPy
    HighsSolver = hs._Highs
    print("Solver: HiGHS bundled with SciPy (pip install highspy to use the package directly)")

SURVEY = "survey_9_to_10.5_credits"     # the only line to change; the other survey: "survey_5_to_9_credits"
SURVEY_DIR = Path("surveys") / SURVEY
DATA_DIR = SURVEY_DIR / "data"
OUTPUT_DIR = SURVEY_DIR / "outputs"
RUNS_DIR = OUTPUT_DIR / "runs"          # one saved file per finished scenario


def read_project_csv(filename):
    path = DATA_DIR / filename
    if not path.is_file():
        raise FileNotFoundError(f"{path} is missing: keep the surveys folder next to this notebook.")
    return pd.read_csv(path, keep_default_na=False)


print("Survey:", SURVEY)

settings = read_project_csv("parameters.csv").set_index("parameter")["value"]


def number_list(text):
    return [float(value) for value in str(text).split(";")]


FLOORS = number_list(settings["FLOORS"])
VERSIONS = str(settings["PGPX_FABM_VERSIONS"]).split(";")
THETAS = number_list(settings["THETA_VALUES"])
MAX_CREDITS = float(settings["MAX_CREDITS"])
OUTSIDE_LIMIT = int(settings["MAX_PGPX_OR_FABM_UNITS"])
LAMBDA = float(settings["LAMBDA"])
N_STUDENTS = int(settings["N_STUDENTS"])
SURVEY_MIN = float(settings["SURVEY_MIN_CREDITS"])
SURVEY_MAX = float(settings["SURVEY_MAX_CREDITS"])
TIME_LIMIT = 20 * 60                   # seconds per solve step (Step 1 and Step 2 each); None = no limit
HEURISTIC_ROUNDS = 2000                # heuristic Step 6: most ruin-and-recreate rounds
HEURISTIC_PATIENCE = 500               # Step 6 stops after this many rounds without a lower shortfall
HEURISTIC_GROUP = 10                   # Step 6: students per round
HEURISTIC_SEED = 2026                  # fixes Step 6's random choices, so a rerun gives the same plan
SHOW_SOLVER_LOG = str(settings["SHOW_SOLVER_LOG"]).strip().lower() == "yes"

SCENARIOS = [(floor, version, theta) for floor in FLOORS for version in VERSIONS for theta in THETAS]
print(f"{len(SCENARIOS)} scenarios: floors {FLOORS}, versions {VERSIONS}, flexibility {THETAS}")
print("Time limit per step:", "none" if TIME_LIMIT is None else f"{TIME_LIMIT / 60:g} minutes")

units = read_project_csv("units.csv").set_index("unit_id", drop=False)
assert units.index.is_unique and units.seat_cap.gt(0).all()

print(units.groupby("programme").agg(units=("unit_id", "size"), seats=("seat_cap", "sum")).to_string())
print("Units that can never move:", sorted(units.index[units.movable.eq(0)]))

sessions = read_project_csv("sessions.csv")
assert not sessions.duplicated(["unit_id", "date", "slot"]).any()
assert set(sessions.unit_id) == set(units.index)

counts = sessions.pivot_table(index="unit_id", columns="session_type", values="date",
                              aggfunc="size", fill_value=0)
assert counts["class"].eq(units.class_sessions.reindex(counts.index)).all()

print("Rows by type:", sessions.session_type.value_counts().to_dict())
print("Units with block days:")
print(counts[counts["block"] > 0].to_string())

survey = read_project_csv("pgp_preference_survey.csv")
assert not survey.duplicated(["student_id", "course"]).any()
assert set(survey.course) <= set(units.index[units.programme.eq("PGP")])
assert survey.credits.eq(survey.course.map(units.credits)).all()

listed = survey.groupby("student_id").credits.sum()
assert len(listed) == N_STUDENTS and listed.between(SURVEY_MIN, SURVEY_MAX).all()
demand_lists = survey.groupby("student_id").course.agg(set).to_dict()

print(f"{len(demand_lists)} students, {len(survey):,} listed courses, lists of {SURVEY_MIN:g} to {SURVEY_MAX:g} credits")
print(listed.value_counts().sort_index().rename("students").to_string())

group_table = read_project_csv("same_content_groups.csv")
assert set(group_table.unit_id) <= set(units.index)
groups = group_table.groupby("group_id").unit_id.agg(set).to_dict()
print(group_table.groupby("group_id").unit_id.agg(", ".join).to_string())

def build_world(units, sessions, groups):
    classes = sessions[sessions.session_type == "class"]
    return {
        "slots": {u: set(zip(g.date, g.slot)) for u, g in sessions.groupby("unit_id")},       # T_s
        "class_slots": {u: set(zip(g.date, g.slot)) for u, g in classes.groupby("unit_id")},
        "movable": units.movable.eq(1).to_dict(),
        "credits": units.credits.to_dict(),                                                   # c_s
        "caps": units.seat_cap.to_dict(),                                                     # cap_s
        "outside": set(units.index[units.is_pgpx_or_fabm.eq(1)]),                             # E
        "group_of": {u: g for g, members in groups.items() for u in members},                 # G
        "max_credits": MAX_CREDITS,                                                           # U
        "outside_limit": OUTSIDE_LIMIT,
    }


world = build_world(units, sessions, groups)

def move_allowance(world, theta):
    return {u: math.floor(theta * len(s) + 0.5) if world["movable"][u] else 0
            for u, s in world["slots"].items()}


def can_move(world, unit, slot, allowance):
    return allowance[unit] > 0 and slot in world["class_slots"].get(unit, set())

def bidding_sets(world, lists, version):
    if version == "with":
        return {i: set(wanted) | world["outside"] for i, wanted in lists.items()}
    if version == "without":
        return {i: set(wanted) for i, wanted in lists.items()}
    raise ValueError(f"Unknown version: {version}")

def clashing_pairs(world, bids):
    bidders = defaultdict(set)
    for student, options in bids.items():
        for u in options:
            bidders[u].add(student)
    pairs = {}
    for a, b in combinations(sorted(bidders), 2):
        if a in world["outside"] and b in world["outside"] and world["outside_limit"] <= 1:
            continue
        group = world["group_of"].get(a)
        if group is not None and group == world["group_of"].get(b):
            continue
        shared = world["slots"][a] & world["slots"][b]                  # T_ab
        students = bidders[a] & bidders[b]                              # I_ab
        if shared and students:
            pairs[a, b] = {"slots": shared, "students": students}
    return pairs

def is_separable(world, pair, shared, allowance):
    a, b = pair
    only_a = only_b = either = 0
    for t in shared:
        move_a = can_move(world, a, t, allowance)
        move_b = can_move(world, b, t, allowance)
        if move_a and move_b:
            either += 1
        elif move_a:
            only_a += 1
        elif move_b:
            only_b += 1
        else:
            return False                      # neither unit can leave this slot
    return (only_a <= allowance[a] and only_b <= allowance[b]
            and only_a + only_b + either <= allowance[a] + allowance[b])

def make_scenario(world, floor, version, theta, bids):
    pairs = clashing_pairs(world, bids)
    allowance = move_allowance(world, theta)
    separable = {p for p, info in pairs.items() if is_separable(world, p, info["slots"], allowance)}
    return {"world": world, "floor": floor, "version": version, "theta": theta, "bids": bids,
            "pairs": pairs, "allowance": allowance, "separable": separable,
            "outside_limit": world["outside_limit"] if version == "with" else 0}


rows = []
for version in VERSIONS:
    bids = bidding_sets(world, demand_lists, version)
    for theta in THETAS:
        sc = make_scenario(world, FLOORS[0], version, theta, bids)
        rows.append({"version": version, "flexibility": theta, "clashing pairs": len(sc["pairs"]),
                     "separable pairs": len(sc["separable"])})
pd.DataFrame(rows)

class MILP:
    def __init__(self):
        self.upper, self.integer = [], []
        self.rows, self.cols, self.vals = [], [], []
        self.row_lo, self.row_hi = [], []
        self.x, self.r, self.m, self.f, self.y = {}, {}, {}, {}, {}

    def add_var(self, upper=1.0, integer=True):
        self.upper.append(upper)
        self.integer.append(1 if integer else 0)
        return len(self.upper) - 1

    def add_row(self, terms, lo=-np.inf, hi=np.inf):
        number = len(self.row_lo)
        for col, coef in terms:
            self.rows.append(number)
            self.cols.append(col)
            self.vals.append(coef)
        self.row_lo.append(lo)
        self.row_hi.append(hi)

    def solve(self, cost, extra_rows=(), show_log=False, start=None):
        rows, cols, vals = list(self.rows), list(self.cols), list(self.vals)
        lo, hi = list(self.row_lo), list(self.row_hi)
        for terms, low, high in extra_rows:
            for col, coef in terms:
                rows.append(len(lo))
                cols.append(col)
                vals.append(coef)
            lo.append(low)
            hi.append(high)
        n, m = len(self.upper), len(lo)
        matrix = coo_matrix((vals, (rows, cols)), shape=(m, n)).tocsr()
        lo, hi, upper = np.array(lo, dtype=float), np.array(hi, dtype=float), np.array(self.upper, dtype=float)

        lp = hs.HighsLp()
        lp.num_col_, lp.num_row_ = n, m
        lp.col_cost_ = np.array([cost.get(j, 0.0) for j in range(n)], dtype=float)
        lp.col_lower_, lp.col_upper_ = np.zeros(n), upper
        lp.row_lower_, lp.row_upper_ = lo, hi
        lp.a_matrix_.format_ = hs.MatrixFormat.kRowwise
        lp.a_matrix_.num_col_, lp.a_matrix_.num_row_ = n, m
        lp.a_matrix_.start_, lp.a_matrix_.index_, lp.a_matrix_.value_ = matrix.indptr, matrix.indices, matrix.data
        lp.integrality_ = [hs.HighsVarType.kInteger if flag else hs.HighsVarType.kContinuous
                           for flag in self.integer]

        solver = HighsSolver()
        solver.setOptionValue("output_flag", bool(show_log))
        solver.setOptionValue("mip_rel_gap", 0.0)
        if TIME_LIMIT is not None:
            solver.setOptionValue("time_limit", float(TIME_LIMIT))
        solver.passModel(lp)

        start_used = False
        if start is not None:
            activity = matrix @ start
            start_used = bool(np.all(activity >= lo - 1e-6) and np.all(activity <= hi + 1e-6)
                              and np.all(start >= -1e-9) and np.all(start <= upper + 1e-9))
            if start_used:
                plan = hs.HighsSolution()
                plan.col_value = list(start)
                plan.value_valid = True
                solver.setSolution(plan)
            else:
                print("Warning: the starting plan breaks a constraint, so HiGHS starts without it.")

        solver.run()
        status, info, solution = solver.getModelStatus(), solver.getInfo(), solver.getSolution()
        found = solution.value_valid
        return {"status": "optimal" if status == hs.HighsModelStatus.kOptimal
                          else "time limit" if status == hs.HighsModelStatus.kTimeLimit
                          else solver.modelStatusToString(status),
                "x": np.array(solution.col_value) if found else None,
                "objective": info.objective_function_value if found else None,
                "bound": info.mip_dual_bound,
                "gap": info.mip_gap if found else None,
                "start_used": start_used}

def add_allotment(model, sc):
    w = sc["world"]
    for i in sorted(sc["bids"]):
        options = sorted(sc["bids"][i])
        for u in options:
            model.x[i, u] = model.add_var()                                     # C0
        model.r[i] = model.add_var(upper=4 * sc["floor"])                    # shortfall in quarters
        quarters = [(model.x[i, u], 4 * w["credits"][u]) for u in options]
        model.add_row(quarters + [(model.r[i], 1)], lo=4 * sc["floor"])       # C1
        model.add_row(quarters, hi=4 * w["max_credits"])                      # C2

def add_outside_limit(model, sc):
    for i, options in sorted(sc["bids"].items()):
        outside = sorted(options & sc["world"]["outside"])
        if outside:
            model.add_row([(model.x[i, u], 1) for u in outside], hi=sc["outside_limit"])  # C3

def add_same_content(model, sc):
    group_of = sc["world"]["group_of"]
    for i, options in sorted(sc["bids"].items()):
        members = defaultdict(list)
        for u in sorted(options):
            if u in group_of:
                members[group_of[u]].append(u)
        for same in members.values():
            if len(same) > 1:
                model.add_row([(model.x[i, u], 1) for u in same], hi=1)          # C4

def add_seat_caps(model, sc):
    holders = defaultdict(list)
    for (i, u), col in model.x.items():
        holders[u].append((col, 1))
    for u, terms in sorted(holders.items()):
        model.add_row(terms, hi=sc["world"]["caps"][u])                     # C5

def add_moves(model, sc):
    w, k = sc["world"], sc["allowance"]
    worth_moving = defaultdict(set)                                          # M_s
    for a, b in sc["separable"]:
        for u in (a, b):
            worth_moving[u] |= {t for t in sc["pairs"][a, b]["slots"] if can_move(w, u, t, k)}
    for u in sorted(worth_moving):
        if not worth_moving[u]:
            continue
        model.f[u] = model.add_var()
        moves = []
        for t in sorted(worth_moving[u]):
            model.m[u, t] = model.add_var()
            model.add_row([(model.m[u, t], 1), (model.f[u], -1)], hi=0)       # C6
            moves.append((model.m[u, t], 1))
        model.add_row(moves + [(model.f[u], -k[u])], hi=0)                   # C6

def add_separation(model, sc):
    for a, b in sorted(sc["separable"]):
        model.y[a, b] = model.add_var()
        for t in sorted(sc["pairs"][a, b]["slots"]):
            terms = [(model.y[a, b], 1)]
            terms += [(model.m[u, t], -1) for u in (a, b) if (u, t) in model.m]
            model.add_row(terms, hi=0)                                         # C7

def add_red_flag(model, sc):
    for (a, b), info in sorted(sc["pairs"].items()):
        separated = model.y.get((a, b))
        for i in sorted(info["students"]):
            terms = [(model.x[i, a], 1), (model.x[i, b], 1)]
            if separated is not None:
                terms.append((separated, -1))
            model.add_row(terms, hi=1)                                         # C8

def build_model(sc):
    model = MILP()
    for add in (add_allotment, add_outside_limit, add_same_content, add_seat_caps,
                add_moves, add_separation, add_red_flag):
        add(model, sc)
    return model

def step1_cost(model):
    cost = {col: LAMBDA / 4 for col in model.r.values()}
    cost.update({col: 1 for col in model.f.values()})
    return cost


def step2_cost(model, sc):
    return {col: -4 * sc["world"]["credits"][u] for (i, u), col in model.x.items()}


def step1_locks(model, sc, first):
    locks = [([(col, 1) for col in model.r.values()], -np.inf, round(4 * first["short"]))]
    if model.f:
        locks.append(([(col, 1) for col in model.f.values()], -np.inf, len(first["asked"])))
    credits = [(col, 4 * sc["world"]["credits"][u]) for (i, u), col in model.x.items()]
    locks.append((credits, round(4 * first["credits"]), np.inf))         # at least Step 1's credits
    return locks

def summarize(sc, allocation, moves):
    w = sc["world"]
    credits = {i: sum(w["credits"][u] for u in held) for i, held in allocation.items()}
    short = {i: max(0.0, sc["floor"] - c) for i, c in credits.items()}
    return {"allocation": {i: set(held) for i, held in allocation.items()},
            "moves": set(moves), "asked": {u for u, t in moves},
            "short": round(sum(short.values()), 2),
            "students_short": sum(v > 1e-9 for v in short.values()),
            "credits": round(sum(credits.values()), 2)}


def read_solution(model, sc, result):
    allocation = {i: set() for i in sc["bids"]}
    for (i, u), col in model.x.items():
        if result["x"][col] > 0.5:
            allocation[i].add(u)
    moves = {key for key, col in model.m.items() if result["x"][col] > 0.5}
    return summarize(sc, allocation, moves)


def solver_report(result, started, scale=1):
    # scale = -0.25 turns Step 2's "minus quarter-credits" back into credits
    bound = result["bound"]
    return {"status": result["status"],
            "found_plan": result["x"] is not None,
            "objective": scale * result["objective"] if result["objective"] is not None else None,
            "bound": scale * bound if bound is not None and np.isfinite(bound) else None,
            "gap": result["gap"],
            "started_from_plan": result["start_used"],
            "seconds": time.time() - started}


def plan_to_start(model, sc, plan):
    # One value per variable, read from a plan's allotment and moves.
    w = sc["world"]
    values = np.zeros(len(model.upper))
    for (i, u), col in model.x.items():
        values[col] = float(u in plan["allocation"][i])
    for i, col in model.r.items():
        quarters = sum(round(4 * w["credits"][u]) for u in plan["allocation"][i])
        values[col] = max(0, round(4 * sc["floor"]) - quarters)
    moves = {key for key in plan["moves"] if key in model.m}    # a move without a variable separates no pair
    for key in moves:
        values[model.m[key]] = 1.0
    for u in {u for u, t in moves}:
        values[model.f[u]] = 1.0
    for (a, b), col in model.y.items():
        values[col] = float(all((a, t) in moves or (b, t) in moves for t in sc["pairs"][a, b]["slots"]))
    return values

def solve_step1(sc, model, show_log=SHOW_SOLVER_LOG):
    started = time.time()
    result = model.solve(step1_cost(model), show_log=show_log)          # no starting values
    if result["x"] is None:
        raise RuntimeError(f"Step 1 found no plan: {result['status']}")
    plan = read_solution(model, sc, result)
    plan["step1"] = solver_report(result, started)
    return plan


def solve_step2(sc, model, first, show_log=SHOW_SOLVER_LOG):
    started = time.time()
    result = model.solve(step2_cost(model, sc), extra_rows=step1_locks(model, sc, first),
                         show_log=show_log, start=plan_to_start(model, sc, first))
    if result["x"] is None:
        raise RuntimeError(f"Step 2 found no plan: {result['status']}")
    plan = read_solution(model, sc, result)
    plan["step1"], plan["step2"] = first["step1"], solver_report(result, started, scale=-0.25)
    plan["step2"]["step1_credits"] = first["credits"]
    assert plan["short"] <= first["short"] + 1e-9 and len(plan["asked"]) <= len(first["asked"])
    assert plan["credits"] >= first["credits"] - 1e-9, "Step 2 has fewer credits than Step 1"
    return plan

def timetable_after(sc, moves):
    occupied = {u: set(s) for u, s in sc["world"]["slots"].items()}
    for u, t in moves:
        occupied[u].discard(t)
    return occupied


def clean_up(sc, plan):
    slots = sc["world"]["slots"]
    holders = defaultdict(set)
    for i, held in plan["allocation"].items():
        for u in held:
            holders[u].add(i)
    moved_in_slot = defaultdict(set)
    for u, t in plan["moves"]:
        moved_in_slot[t].add(u)
    kept = set()
    for t, moved in sorted(moved_in_slot.items()):
        meeting = sorted(u for u in slots if t in slots[u])
        clashes = [(a, b) for a, b in combinations(meeting, 2) if holders[a] & holders[b]]
        for size in range(len(moved) + 1):
            choice = next((set(c) for c in combinations(sorted(moved), size)
                           if all(a in c or b in c for a, b in clashes)), None)
            if choice is not None:
                kept |= {(u, t) for u in choice}
                break
    return dict(plan, **summarize(sc, plan["allocation"], kept))

def check_plan(sc, plan):
    w, k = sc["world"], sc["allowance"]
    per_unit = Counter(u for u, t in plan["moves"])
    for u, t in plan["moves"]:
        assert can_move(w, u, t, k), f"{u} cannot move its session at {t}"
    for u, n in per_unit.items():
        assert n <= k[u], f"{u} moves {n} sessions, more than its allowance {k[u]}"
    occupied = timetable_after(sc, plan["moves"])
    seats = Counter()
    for i, held in plan["allocation"].items():
        assert held <= sc["bids"][i], f"{i} got a unit outside their bidding set"
        assert len(held & w["outside"]) <= sc["outside_limit"], f"{i} breaks the PGPX/FABM limit"
        same = [w["group_of"][u] for u in held if u in w["group_of"]]
        assert len(same) == len(set(same)), f"{i} holds two units with the same content"
        assert sum(w["credits"][u] for u in held) <= w["max_credits"] + 1e-9, f"{i} is above 9 credits"
        for a, b in combinations(sorted(held), 2):
            assert not occupied[a] & occupied[b], f"{i} has a clash between {a} and {b}"
        seats.update(held)
    for u, n in seats.items():
        assert n <= w["caps"][u], f"{u} has {n} students for {w['caps'][u]} seats"
    fresh = summarize(sc, plan["allocation"], plan["moves"])
    for key in ("short", "students_short", "credits", "asked"):
        assert fresh[key] == plan[key], f"{key} does not match a fresh count"

def run_exact(world, lists, floor, version, theta, show_log=SHOW_SOLVER_LOG):
    sc = make_scenario(world, floor, version, theta, bidding_sets(world, lists, version))
    model = build_model(sc)
    first = solve_step1(sc, model, show_log)
    check_plan(sc, first)
    final = clean_up(sc, solve_step2(sc, model, first, show_log))
    check_plan(sc, final)
    final["model_size"] = {"variables": len(model.upper), "constraints": len(model.row_lo)}
    return final

def prepare(sc):
    w = sc["world"]
    assert sc["outside_limit"] == 1 or not any(b & w["outside"] for b in sc["bids"].values())
    slots = sorted(set().union(*w["slots"].values()))
    bits = {t: 1 << n for n, t in enumerate(slots)}
    for group in sorted(set(w["group_of"].values())):          # same content: a shared dummy slot
        bits["group", group] = 1 << len(bits)
    bits["outside"] = 1 << len(bits)                           # PGPX/FABM limit of one: same idea
    base = {}
    for u, ts in w["slots"].items():
        m = sum(bits[t] for t in ts)
        if u in w["group_of"]:
            m |= bits["group", w["group_of"][u]]
        if u in w["outside"]:
            m |= bits["outside"]
        base[u] = m
    listers = defaultdict(set)
    for i, b in sc["bids"].items():
        for u in b:
            listers[u].add(i)
    sc.update(bits=bits, base_mask=base, listers=listers, cache={},
              q={u: round(4 * c) for u, c in w["credits"].items()},
              floor4=round(4 * sc["floor"]), max4=round(4 * w["max_credits"]),
              order={i: sorted(b, key=lambda u: (-round(4 * w["credits"][u]), u)) for i, b in sc["bids"].items()})
    return sc


def masks_after(sc, moves):
    mask = dict(sc["base_mask"])
    for u, t in moves:
        mask[u] &= ~sc["bits"][t]
    return mask


def bound_left(sc, order):
    # left[j]: most credits order[j:] can add if time clashes did not matter (one PGPX/FABM unit,
    # one unit per group). Never below the truth, so the search drops only branches that cannot win.
    w, q = sc["world"], sc["q"]
    left, top, total = [0] * (len(order) + 1), {}, 0
    for j in range(len(order) - 1, -1, -1):
        u = order[j]
        key = "outside" if u in w["outside"] else w["group_of"].get(u, u)
        if q[u] > top.get(key, 0):
            total += q[u] - top.get(key, 0)
            top[key] = q[u]
        left[j] = total
    return left


def most_credits(sc, options, mask, room, stop=None, return_set=False, order=None):
    # Most quarter-credits from a clash-free set within `room`; stops once it reaches `stop`.
    q = sc["q"]
    order = order or sorted(options, key=lambda u: (-q[u], u))
    credit, bit, left = [q[u] for u in order], [mask[u] for u in order], bound_left(sc, order)
    stop, n, best = room if stop is None else stop, len(order), [0, 0]

    def search(j, chosen, used, total):
        if total > best[0]:
            best[0], best[1] = total, chosen
        if best[0] >= stop or j == n or total + left[j] <= best[0]:
            return
        if total + credit[j] <= room and not used & bit[j]:
            search(j + 1, chosen | 1 << j, used | bit[j], total + credit[j])
        search(j + 1, chosen, used, total)

    search(0, 0, 0, 0)
    if not return_set:
        return best[0]
    return best[0], {order[j] for j in range(n) if best[1] >> j & 1}


def fewest_credits_cover(sc, options, mask, target, preference):
    q = sc["q"]
    order = sorted(options, key=lambda u: (-q[u], u))
    credit, bit, left = [q[u] for u in order], [mask[u] for u in order], bound_left(sc, order)
    pref, n, best = [preference[u] for u in order], len(order), [None, None, 0]

    def search(j, chosen, used, total, score):
        if best[0] is not None and total > best[0]:
            return
        if total >= target:
            if best[0] is None or total < best[0] or score > best[1]:
                best[:] = [total, score, chosen]
            return
        if j == n or total + left[j] < target:
            return
        if not used & bit[j]:
            search(j + 1, chosen | 1 << j, used | bit[j], total + credit[j], score + pref[j])
        search(j + 1, chosen, used, total, score)

    search(0, 0, 0, 0, 0.0)
    return None if best[0] is None else {order[j] for j in range(n) if best[2] >> j & 1}


def student_best(sc, i, mask, stop):
    order = sc["order"][i]
    key = (i, stop, tuple(mask[u] for u in order))
    if key not in sc["cache"]:
        sc["cache"][key] = most_credits(sc, None, mask, sc["max4"], stop, order=order)
    return sc["cache"][key]


def gap(sc, i, mask):
    return max(0, sc["floor4"] - student_best(sc, i, mask, sc["floor4"]))


def touched(sc, students, mask, extra):
    # Students whose best can change: they list a moved unit and another unit meeting in a moved slot.
    moved = defaultdict(int)
    for u, t in extra:
        moved[u] |= sc["bits"][t]
    return [i for i in students
            if any(u in sc["bids"][i] and any(mask[u] & mask[v] & m for v in sc["bids"][i] if v != u)
                   for u, m in moved.items())]

def best_moves_for(sc, occupied, unit, short, already):
    w, k = sc["world"], sc["allowance"]
    room = k[unit] - len(already)
    if room <= 0:
        return set()
    blocking = Counter()
    for i in short:
        if unit not in sc["bids"][i]:
            continue
        for v in sc["bids"][i] - {unit}:
            for t in occupied[unit] & occupied[v]:
                if can_move(w, unit, t, k):
                    blocking[t] += 1
    ranked = sorted(blocking, key=lambda t: (-blocking[t], t))
    return {(unit, t) for t in ranked[:room]}


def score_move(sc, moves, mask, extra, students, gaps_now):
    hit = touched(sc, students, mask, extra)
    after = masks_after(sc, moves | extra)
    return sum(gaps_now[i] for i in hit) - sum(gap(sc, i, after) for i in hit)


def pair_rescue(sc, moves, occupied, mask, short, gaps_now):
    w, k, bids = sc["world"], sc["allowance"], sc["bids"]
    used, short_set = Counter(u for u, t in moves), set(short)
    best_key, best_extra = None, set()
    for (a, b), info in sorted(sc["pairs"].items()):
        if (a, b) not in sc["separable"] or not info["students"] & short_set:
            continue
        extra, room = set(), {a: k[a] - used[a], b: k[b] - used[b]}
        for t in sorted(occupied[a] & occupied[b]):
            mover = next((u for u in (a, b) if room[u] > 0 and can_move(w, u, t, k)), None)
            if mover is None:
                extra = None
                break
            extra.add((mover, t))
            room[mover] -= 1
        if not extra:
            continue
        affected = [i for i in short if a in bids[i] or b in bids[i]]
        gain = score_move(sc, moves, mask, extra, affected, gaps_now)
        new_courses = len({u for u, t in extra} - set(used))
        if gain > 0:
            key = (gain / max(new_courses, 1), -len(extra), a, b)
            if best_key is None or key > best_key:
                best_key, best_extra = key, extra
    return best_extra


def fix_timetable(sc):                                         # Step 1
    w, k, bids = sc["world"], sc["allowance"], sc["bids"]
    moves = set()
    mask = masks_after(sc, moves)
    gaps_now = {i: gap(sc, i, mask) for i in bids}
    while True:
        short = sorted(i for i in bids if gaps_now[i] > 0)
        if not short:
            return moves
        occupied, asked = timetable_after(sc, moves), {u for u, t in moves}
        best_key, best_extra = None, None
        for unit in sorted(u for u in w["slots"] if k[u] > 0):
            already = {(u, t) for u, t in moves if u == unit}
            extra = best_moves_for(sc, occupied, unit, short, already)
            if not extra:
                continue
            gain = score_move(sc, moves, mask, extra, [i for i in short if unit in bids[i]], gaps_now)
            if gain <= 0:
                continue
            key = (unit in asked, gain, -len(extra), unit)
            if best_key is None or key > best_key:
                best_key, best_extra = key, extra
        if best_extra is None:
            best_extra = pair_rescue(sc, moves, occupied, mask, short, gaps_now)
        if not best_extra:
            return moves
        moves |= best_extra
        mask = masks_after(sc, moves)
        for i in set().union(*(sc["listers"][u] for u, t in best_extra)):
            gaps_now[i] = gap(sc, i, mask)

class Seats:
    """Who holds which course and how many seats are left, for one timetable (mask)."""

    def __init__(self, sc, mask):
        self.sc, self.mask = sc, mask
        self.free = dict(sc["world"]["caps"])
        self.held = {i: set() for i in sc["bids"]}
        self.holders = defaultdict(set)
        self.log = []                                           # (student, unit, +1 given / -1 taken)

    def credit(self, i):
        return sum(self.sc["q"][u] for u in self.held[i])

    def give(self, i, u):
        assert self.free[u] > 0, f"no free seat in {u}"
        self.held[i].add(u); self.holders[u].add(i); self.free[u] -= 1
        self.log.append((i, u, 1))

    def take_back(self, i, u):
        self.held[i].remove(u); self.holders[u].discard(i); self.free[u] += 1
        self.log.append((i, u, -1))

    def undo(self, mark):
        while len(self.log) > mark:
            i, u, sign = self.log.pop()
            if sign == 1:
                self.held[i].remove(u); self.holders[u].discard(i); self.free[u] += 1
            else:
                self.held[i].add(u); self.holders[u].add(i); self.free[u] -= 1

    def fits(self, current, u):
        q = self.sc["q"]
        if u in current or sum(q[v] for v in current) + q[u] > self.sc["max4"]:
            return False
        used = 0
        for v in current:
            used |= self.mask[v]
        return not used & self.mask[u]

    def short(self):
        return sum(max(0, self.sc["floor4"] - self.credit(i)) for i in self.held)


def static_order(sc, mask):
    return sorted(sc["bids"], key=lambda i: (student_best(sc, i, mask, sc["max4"]), i))


def first_allotment(s, order):                                 # Step 2
    sc = s.sc
    bids, floor4, max4 = sc["bids"], sc["floor4"], sc["max4"]
    still_to_come = Counter(u for i in order for u in bids[i])
    for i in order:
        still_to_come.subtract(bids[i])
        open_units = {u for u in bids[i] if s.free[u] > 0}
        preference = {u: s.free[u] / (1 + still_to_come[u]) for u in open_units}
        chosen = fewest_credits_cover(sc, open_units, s.mask, floor4, preference)
        if chosen is None:
            chosen = most_credits(sc, open_units, s.mask, max4, return_set=True)[1]
        for u in chosen:
            s.give(i, u)

def repick(s, i):
    sc, q = s.sc, s.sc["q"]
    bids, floor4, max4 = sc["bids"], sc["floor4"], sc["max4"]
    spare = {}

    def spare_of(j):
        return spare.setdefault(j, s.credit(j) - floor4)

    releasable = {u for u in bids[i] - s.held[i] if s.free[u] == 0
                  and any(spare_of(j) >= q[u] for j in s.holders[u])}
    available = s.held[i] | {u for u in bids[i] if s.free[u] > 0} | releasable
    value, chosen = most_credits(sc, available, s.mask, floor4, return_set=True)
    if value < floor4:
        value_up, chosen_up = most_credits(sc, available, s.mask, max4, return_set=True)
        if value_up >= floor4:
            value, chosen = value_up, chosen_up
    if value <= s.credit(i):
        return False
    releasers = {}
    for u in chosen - s.held[i]:
        if s.free[u] > 0:
            continue
        giver = next((j for j in sorted(s.holders[u]) if spare_of(j) >= q[u]), None)
        if giver is None:
            return False
        spare[giver] -= q[u]
        releasers[u] = giver
    for u in s.held[i] - chosen:
        s.take_back(i, u)
    for u in chosen - s.held[i]:
        if u in releasers:
            s.take_back(releasers[u], u)
        s.give(i, u)
    return True


def make_room(s, u, chain, depth=2):
    sc = s.sc
    for j in sorted(s.holders[u] - chain):
        need = min(s.credit(j), sc["floor4"])
        pool = (s.held[j] - {u}) | {v for v in sc["bids"][j] if v != u and (s.free[v] > 0 or depth > 1)}
        preference = {v: 2 if v in s.held[j] else 1 if s.free[v] > 0 else 0 for v in pool}
        cover = fewest_credits_cover(sc, pool, s.mask, need, preference)
        if cover is None:
            continue
        missing = sorted(v for v in cover - s.held[j] if s.free[v] == 0)
        if not all(make_room(s, v, chain | {j}, depth - 1) for v in missing):
            continue
        if any(s.free[v] == 0 for v in cover - s.held[j]):
            continue
        for v in s.held[j] - cover:
            s.take_back(j, v)
        for v in cover - s.held[j]:
            s.give(j, v)
        return True
    return False


def deep_repick(s, i):
    sc, q = s.sc, s.sc["q"]
    bids = sc["bids"]
    preference = {u: 2 if u in s.held[i] else 1 if s.free[u] > 0 else 0 for u in bids[i]}
    chosen = fewest_credits_cover(sc, bids[i], s.mask, sc["floor4"], preference)
    if chosen is None:
        chosen = most_credits(sc, bids[i], s.mask, sc["max4"], return_set=True)[1]
    if sum(q[u] for u in chosen) <= s.credit(i):
        return False
    for u in sorted(chosen - s.held[i]):
        if s.free[u] == 0 and not make_room(s, u, {i}):
            return False
    if any(s.free[u] == 0 for u in chosen - s.held[i]):
        return False
    for u in s.held[i] - chosen:
        s.take_back(i, u)
    for u in chosen - s.held[i]:
        s.give(i, u)
    return True


def switch_trade(s, i):
    sc, q = s.sc, s.sc["q"]
    bids, floor4 = sc["bids"], sc["floor4"]
    for u in sorted(bids[i] - s.held[i], key=lambda u: (-q[u], u)):
        if s.free[u] > 0 or not s.fits(s.held[i], u):
            continue
        for j in sorted(s.holders[u]):
            others = s.held[j] - {u}
            keep = min(s.credit(j), floor4)
            switch = [v for v in bids[j] if s.free[v] > 0 and v != u
                      and s.fits(others, v) and sum(q[z] for z in others) + q[v] >= keep]
            if switch:
                v = max(switch, key=lambda v: (q[v], s.free[v], v))
                s.take_back(j, u); s.give(j, v); s.give(i, u)
                return True
    return False


def repair(s):                                                 # Step 3
    changed = True
    while changed:
        changed = False
        short = [i for i in s.held if s.credit(i) < s.sc["floor4"]]
        for i in sorted(short, key=lambda i: (s.credit(i), i)):
            if repick(s, i) or deep_repick(s, i) or switch_trade(s, i):
                changed = True


def allot_core(sc, moves):
    mask = masks_after(sc, moves)
    s = Seats(sc, mask)
    order = static_order(sc, mask)
    first_allotment(s, order)
    repair(s)
    return s, order

def free_gap(sc, options, mask, cache):
    key = (tuple(sorted(options)), tuple(mask[u] for u in sorted(options)))
    if key not in cache:
        cache[key] = max(0, sc["floor4"] - most_credits(sc, options, mask, sc["max4"], stop=sc["floor4"]))
    return cache[key]


def unblock(sc, s, moves):                                  # Step 5
    # With the allowance left, move the sessions that keep short students from courses with free
    # seats, picking the course whose move closes the most credits; a course already asked costs nothing.
    w, k, bids, floor4 = sc["world"], sc["allowance"], sc["bids"], sc["floor4"]
    while True:
        short = sorted(i for i in s.held if s.credit(i) < floor4)
        if not short:
            return moves
        options = {i: s.held[i] | {u for u in bids[i] if s.free[u] > 0} for i in short}
        cache = {}
        gaps_now = {i: free_gap(sc, options[i], s.mask, cache) for i in short}
        occupied, used = timetable_after(sc, moves), Counter(u for u, t in moves)
        best_key, best_extra, best_hit = None, None, None
        for unit in sorted(u for u in w["slots"] if k[u] - used[u] > 0):
            mine = [i for i in short if unit in options[i]]
            blocking = Counter(t for i in mine for v in options[i] - {unit}
                               for t in occupied[unit] & occupied[v] if can_move(w, unit, t, k))
            extra = {(unit, t) for t in sorted(blocking, key=lambda t: (-blocking[t], t))[:k[unit] - used[unit]]}
            if not extra:
                continue
            moved = sum(sc["bits"][t] for u, t in extra)
            hit = [i for i in mine if any(s.mask[unit] & s.mask[v] & moved for v in options[i] if v != unit)]
            after = masks_after(sc, moves | extra)
            gain = sum(gaps_now[i] - free_gap(sc, options[i], after, cache) for i in hit)
            if gain <= 0:
                continue
            key = (unit in used, gain, -len(extra), unit)
            if best_key is None or key > best_key:
                best_key, best_extra, best_hit = key, extra, hit
        if best_extra is None:
            return moves
        moves = moves | best_extra
        s.mask = masks_after(sc, moves)
        for i in sorted(best_hit, key=lambda i: (s.credit(i), i)):
            repick(s, i)

def pick_group(s, rng, size):
    # A short student picked at random, then students linked to the group through a course
    # that a member listed: a random holder of a random listed course, until the group has `size`.
    bids = s.sc["bids"]
    short = sorted(i for i in s.held if s.credit(i) < s.sc["floor4"])
    if not short:
        return []
    group = [rng.choice(short)]
    for _ in range(20 * size):
        if len(group) == size:
            break
        u = rng.choice(sorted(bids[rng.choice(group)]))
        others = sorted(s.holders[u] - set(group))
        if others:
            group.append(rng.choice(others))
    return group


def hand_out_again(s, group):
    # Least slack first: the member who can reach the fewest credits from free seats picks next.
    sc = s.sc
    bids, floor4, max4 = sc["bids"], sc["floor4"], sc["max4"]
    waiting = set(group)
    still_to_come = Counter(u for i in group for u in bids[i])
    while waiting:
        reach = {i: most_credits(sc, {u for u in bids[i] if s.free[u] > 0}, s.mask, max4) for i in waiting}
        i = min(waiting, key=lambda i: (reach[i], i))
        waiting.discard(i)
        still_to_come.subtract(bids[i])
        open_units = {u for u in bids[i] if s.free[u] > 0}
        preference = {u: s.free[u] / (1 + still_to_come[u]) for u in open_units}
        chosen = fewest_credits_cover(sc, open_units, s.mask, floor4, preference)
        if chosen is None:
            chosen = most_credits(sc, open_units, s.mask, max4, return_set=True)[1]
        for u in chosen:
            s.give(i, u)
    for i in sorted(group, key=lambda i: (s.credit(i), i)):
        if s.credit(i) < floor4:
            repick(s, i) or switch_trade(s, i)


def change_since(s, mark):
    # Change in (credits short, total credits) from the moves logged since `mark`.
    q, floor4 = s.sc["q"], s.sc["floor4"]
    delta = Counter()
    for i, u, sign in s.log[mark:]:
        delta[i] += sign * q[u]
    short = sum(max(0, floor4 - s.credit(i)) - max(0, floor4 - (s.credit(i) - d)) for i, d in delta.items())
    return short, sum(delta.values())


def ruin_and_recreate(s, rounds, patience, size, seed):        # Step 6
    rng = random.Random(seed)
    calm = done = 0
    for done in range(1, rounds + 1):
        group = pick_group(s, rng, size)
        if not group:
            break
        mark = len(s.log)
        for i in group:
            for u in sorted(s.held[i]):
                s.take_back(i, u)
        hand_out_again(s, group)
        short, credits = change_since(s, mark)
        if short > 0 or (short == 0 and credits < 0):
            s.undo(mark)                                        # worse: put the seats back
        calm = 0 if short < 0 else calm + 1
        if calm >= patience:
            break
    s.log.clear()
    return done

def fill(s, order):                                            # Step 7
    sc, q = s.sc, s.sc["q"]
    bids = sc["bids"]
    changed = True
    while changed:
        changed = False
        for i in order:
            for u in sorted(bids[i] - s.held[i], key=lambda u: (-q[u], u)):
                if s.free[u] > 0 and s.fits(s.held[i], u):
                    s.give(i, u)
                    changed = True
            for u in sorted(s.held[i], key=lambda u: (q[u], u)):
                bigger = [v for v in bids[i] if s.free[v] > 0 and q[v] > q[u] and s.fits(s.held[i] - {u}, v)]
                if bigger:
                    v = max(bigger, key=lambda v: (q[v], v))
                    s.take_back(i, u); s.give(i, v)
                    changed = True
                    break


def score(s):
    return (s.short(), -sum(s.credit(i) for i in s.held))


def trim_courses(sc, s, order, moves):                        # Step 4
    def helped(unit):
        occupied = timetable_after(sc, {m for m in moves if m[0] != unit})
        return sum(1 for held in s.held.values() if unit in held
                   and any(occupied[unit] & occupied[v] for v in held - {unit}))

    for unit in sorted({u for u, t in moves}, key=lambda u: (helped(u), u)):
        trial_moves = {m for m in moves if m[0] != unit}
        mine = sc["listers"][unit]
        now, without = masks_after(sc, moves), masks_after(sc, trial_moves)
        if sum(gap(sc, i, without) for i in mine) > sum(gap(sc, i, now) for i in mine):
            continue                                           # undoing this course leaves someone short
        trial, trial_order = allot_core(sc, trial_moves)
        if trial.short() <= s.short():
            s, order, moves = trial, trial_order, trial_moves
    return s, order, moves


def run_heuristic(world, lists, floor, version, theta):
    started = time.time()
    sc = prepare(make_scenario(world, floor, version, theta, bidding_sets(world, lists, version)))
    moves = fix_timetable(sc)                                  # Step 1
    s, order = allot_core(sc, moves)                           # Steps 2 and 3
    s, order, moves = trim_courses(sc, s, order, moves)        # Step 4
    widened = unblock(sc, s, moves)                            # Step 5
    if widened != moves:
        moves = widened
        repair(s)
    lowest = sum(gap(sc, i, s.mask) for i in sc["bids"])      # shortfall even with unlimited seats
    if s.short() > lowest:                                     # Step 6, only when seats cause shortfall
        kept = {i: set(held) for i, held in s.held.items()}
        ruin_and_recreate(s, HEURISTIC_ROUNDS, HEURISTIC_PATIENCE, HEURISTIC_GROUP, HEURISTIC_SEED)
        before = Seats(sc, s.mask)
        for i, held in kept.items():
            for u in held:
                before.give(i, u)
        fill(before, order)                                    # Step 7 on both plans; keep the better
        fill(s, order)
        if score(before) < score(s):
            s = before
    else:
        fill(s, order)                                         # Step 7
    plan = clean_up(sc, summarize(sc, s.held, moves))
    check_plan(sc, plan)
    plan["seconds"] = time.time() - started
    return plan

def toy_world(slots, outside=(), blocks=(), ceiling=9):
    names = sorted(slots)
    return {
        "slots": {u: set(s) for u, s in slots.items()},
        "class_slots": {u: set(s) - {t for v, t in blocks if v == u} for u, s in slots.items()},
        "movable": dict.fromkeys(names, True),
        "credits": dict.fromkeys(names, 1.0),
        "caps": dict.fromkeys(names, 10),
        "outside": set(outside), "group_of": {},
        "max_credits": ceiling, "outside_limit": 1,
    }


def toy_run(world, lists, floor, theta, version="with"):
    heuristic = run_heuristic(world, lists, floor, version, theta)
    exact = run_exact(world, lists, floor, version, theta, show_log=False)
    return exact, heuristic

test_a = toy_world({"A": {("d", "t1"), ("d", "t2")}, "B": {("d", "t1"), ("d", "t3")},
                    "C": {("d", "t3"), ("d", "t4")}}, ceiling=2)
lists_a = {"S1": {"A", "B"}, "S2": {"B", "C"}, "S3": {"A", "B"}}
for theta, short, asked in [(0, 3, 0), (0.5, 0, 2), (1, 0, 1)]:
    exact, heuristic = toy_run(test_a, lists_a, 2, theta)
    for name, plan in (("solver", exact), ("heuristic", heuristic)):
        assert (plan["short"], len(plan["asked"])) == (short, asked), (name, theta, plan)
    if theta == 1:
        assert exact["asked"] == heuristic["asked"] == {"B"}
    print(f"Test A, θ = {theta:.0%}: shortfall {short}, courses asked {asked}. Solver and heuristic pass.")

test_b = toy_world({"A": {("d", "t1")}, "P": {("d", "t2")}, "Q": {("d", "t3")}}, outside={"P", "Q"})
exact, heuristic = toy_run(test_b, {"S1": {"A"}}, 3, 0)
for plan in (exact, heuristic):
    assert plan["short"] == 1 and plan["allocation"]["S1"] in ({"A", "P"}, {"A", "Q"})
print("Test B: at most one PGPX/FABM unit, shortfall 1. Solver and heuristic pass.")

test_c = toy_world({"A": {("d", "t1"), ("d", "t2")}, "B": {("d", "t1"), ("d", "t3")}},
                   blocks={("A", ("d", "t1"))})
exact, heuristic = toy_run(test_c, {"S1": {"A", "B"}}, 2, 0.5)
for plan in (exact, heuristic):
    assert plan["short"] == 0 and plan["moves"] == {("B", ("d", "t1"))}
print("Test C: the block day stays put and B moves instead. Solver and heuristic pass.")

test_d = toy_world({"A": {("d", "t1")}, "P": {("d", "t2")}}, outside={"P"})
for version, short, held in (("with", 0, {"A", "P"}), ("without", 1, {"A"})):
    exact, heuristic = toy_run(test_d, {"S1": {"A"}}, 2, 0, version)
    for plan in (exact, heuristic):
        assert plan["short"] == short and plan["allocation"]["S1"] == held
print("Test D: the 'without' version never gives a PGPX/FABM unit. Solver and heuristic pass.")

def run_file(kind, floor, version, theta):
    return RUNS_DIR / f"{kind}_floor{floor:g}_{version}_theta{round(theta * 100):02d}.pkl"


def load_or_run(kind, floor, version, theta, solver):
    path = run_file(kind, floor, version, theta)
    if path.is_file():
        with open(path, "rb") as handle:
            return pickle.load(handle)
    started = time.time()
    plan = solver()
    plan["total_seconds"] = time.time() - started
    RUNS_DIR.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as handle:
        pickle.dump(plan, handle)
    return plan


def describe(plan):
    return (f"{plan['short']:g} credits short ({plan['students_short']} students), "
            f"{len(plan['asked'])} courses asked, {len(plan['moves'])} sessions moved, "
            f"{plan['credits']:,.2f} credits")

heuristic_runs = {}
for floor, version, theta in SCENARIOS:
    started = time.time()
    plan = run_heuristic(world, demand_lists, floor, version, theta)
    plan["total_seconds"] = time.time() - started
    RUNS_DIR.mkdir(parents=True, exist_ok=True)
    with open(run_file("heuristic", floor, version, theta), "wb") as handle:
        pickle.dump(plan, handle)
    heuristic_runs[floor, version, theta] = plan
    print(f"Heuristic | floor {floor:g}, {version}, θ {theta:.0%}: {describe(plan)} "
          f"[{plan['total_seconds']:.1f} s]")

solver_runs = {}
for floor, version, theta in SCENARIOS:
    plan = load_or_run("solver", floor, version, theta,
                       lambda: run_exact(world, demand_lists, floor, version, theta))
    solver_runs[floor, version, theta] = plan
    s1, s2 = plan["step1"], plan["step2"]
    print(f"Solver | floor {floor:g}, {version}, θ {theta:.0%}: {describe(plan)} "
          f"[Step 1 {s1['status']}, {s1['seconds']:.0f} s; Step 2 {s2['status']}, {s2['seconds']:.0f} s]")

def load_runs(kind):
    found = {}
    for floor, version, theta in SCENARIOS:
        path = run_file(kind, floor, version, theta)
        if path.is_file():
            with open(path, "rb") as handle:
                found[floor, version, theta] = pickle.load(handle)
    return found


solver_runs, heuristic_runs = load_runs("solver"), load_runs("heuristic")
print(f"Finished: {len(solver_runs)} solver and {len(heuristic_runs)} heuristic runs out of {len(SCENARIOS)}.")

def summary_row(key, plan, method):
    floor, version, theta = key
    row = {"Floor": floor, "Version": version, "Flexibility": theta, "Method": method,
           "Total shortfall": plan["short"], "Students short": plan["students_short"],
           "Courses asked": len(plan["asked"]), "Sessions moved": len(plan["moves"]),
           "Total credits": plan["credits"],
           "Credits per student": round(plan["credits"] / len(plan["allocation"]), 3),
           "Seconds": round(plan["total_seconds"]) if method == "Solver" else round(plan["total_seconds"], 1)}
    if method == "Solver":
        s1, s2 = plan["step1"], plan["step2"]
        row.update({"Step 1 status": s1["status"],
                    "Score": LAMBDA * plan["short"] + len(plan["asked"]),
                    "Step 1 bound": s1["bound"], "Step 2 status": s2["status"],
                    "Step 1 plan credits": s2["step1_credits"], "Step 2 credit bound": s2["bound"]})
    return row


summary = pd.DataFrame([summary_row(k, p, "Solver") for k, p in solver_runs.items()] +
                       [summary_row(k, p, "Heuristic") for k, p in heuristic_runs.items()])
if not summary.empty:
    summary = summary.sort_values(["Floor", "Version", "Flexibility", "Method"], ignore_index=True)
summary

FLOOR_COLORS = ["#2a78d6", "#eb6834", "#1baf7a"]
solver_table = summary[summary.Method == "Solver"]
panels = [("Courses asked", "Courses asked to move"), ("Students short", "Students below the floor"),
          ("Credits per student", "Credits per student")]
fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
for ax, (column, title) in zip(axes, panels):
    for color, floor in zip(FLOOR_COLORS, FLOORS):
        for version, style in (("with", "-"), ("without", "--")):
            part = solver_table[(solver_table.Floor == floor) & (solver_table.Version == version)]
            if part.empty:
                continue
            part = part.sort_values("Flexibility")
            ax.plot(part.Flexibility * 100, part[column], style, marker="o", color=color, linewidth=2,
                    markersize=6, label=f"floor {floor:g}, {version}")
    ax.set_title(title)
    ax.set_xlabel("Flexibility θ (% of sessions)")
    ax.grid(axis="y", alpha=0.3)
    ax.spines[["top", "right"]].set_visible(False)
axes[0].legend(frameon=False, fontsize=9)
plt.tight_layout()
plt.show()

compare = summary.pivot_table(index=["Floor", "Version", "Flexibility"], columns="Method",
                              values=["Total shortfall", "Courses asked", "Total credits", "Seconds"])
compare.columns = [f"{measure} ({method.lower()})" for measure, method in compare.columns]
if {"Total credits (solver)", "Total credits (heuristic)"} <= set(compare.columns):
    compare["Credit gap (%)"] = (100 * (compare["Total credits (solver)"] - compare["Total credits (heuristic)"])
                                 / compare["Total credits (solver)"]).round(2)
compare.reset_index()

def moved_session_rows(key, plan):
    floor, version, theta = key
    occupied = timetable_after({"world": world}, plan["moves"])
    rows = []
    for unit, (date, slot) in sorted(plan["moves"]):
        pairs, students = set(), set()
        for i, held in plan["allocation"].items():
            if unit not in held:
                continue
            for other in held - {unit}:
                if (date, slot) in occupied[other]:
                    pairs.add(" + ".join(sorted((unit, other))))
                    students.add(i)
        rows.append({"Floor": floor, "Version": version, "Flexibility": theta, "unit_id": unit,
                     "course_name": units.at[unit, "course_name"], "instructors": units.at[unit, "instructors"],
                     "date": date, "slot": slot, "Pairs kept apart": ", ".join(sorted(pairs)),
                     "Students helped": len(students), "Student IDs": ", ".join(sorted(students))})
    return rows


def course_asked_rows(key, plan, session_rows):
    floor, version, theta = key
    allowance = move_allowance(world, theta)
    rows = []
    for unit in sorted(plan["asked"]):
        mine = [r for r in session_rows if r["unit_id"] == unit]
        helped = set()
        for r in mine:
            helped |= {i for i in r["Student IDs"].split(", ") if i}
        rows.append({"Floor": floor, "Version": version, "Flexibility": theta, "unit_id": unit,
                     "course_name": units.at[unit, "course_name"], "instructors": units.at[unit, "instructors"],
                     "Sessions moved": len(mine), "Allowance k": allowance[unit],
                     "Moved slots": "; ".join(f"{r['date']} {r['slot']}" for r in mine),
                     "Students helped": len(helped)})
    return rows


moved_rows, asked_rows = [], []
for key, plan in solver_runs.items():
    rows = moved_session_rows(key, plan)
    moved_rows += rows
    asked_rows += course_asked_rows(key, plan, rows)
moved_sessions = pd.DataFrame(moved_rows)
courses_asked = pd.DataFrame(asked_rows)
courses_asked

def by_student_rows(key, plan):
    floor, version, theta = key
    rows = []
    for i, held in sorted(plan["allocation"].items()):
        credits = sum(units.at[u, "credits"] for u in held)
        rows.append({"Floor": floor, "Version": version, "Flexibility": theta, "student_id": i,
                     "Credits listed": sum(units.at[u, "credits"] for u in demand_lists[i]),
                     "Courses listed": ", ".join(sorted(demand_lists[i])),
                     "Credits allotted": credits, "Courses allotted": ", ".join(sorted(held)),
                     "Number of courses": len(held), "Shortfall": max(0.0, floor - credits)})
    return rows


def by_course_rows(key, plan):
    floor, version, theta = key
    holders = defaultdict(set)
    for i, held in plan["allocation"].items():
        for u in held:
            holders[u].add(i)
    moved = Counter(u for u, t in plan["moves"])
    rows = []
    for u in units.index:
        rows.append({"Floor": floor, "Version": version, "Flexibility": theta, "unit_id": u,
                     "course_name": units.at[u, "course_name"], "programme": units.at[u, "programme"],
                     "credits": units.at[u, "credits"], "Seat cap": units.at[u, "seat_cap"],
                     "Seats used": len(holders[u]), "Seats free": units.at[u, "seat_cap"] - len(holders[u]),
                     "Sessions moved": moved[u], "Students": ", ".join(sorted(holders[u]))})
    return rows


def allotment_matrix(plan):
    matrix = pd.DataFrame(0, index=sorted(plan["allocation"]), columns=list(units.index))
    for i, held in plan["allocation"].items():
        for u in held:
            matrix.at[i, u] = 1
    matrix.index.name = "student_id"
    return matrix


def sheet_name(key):
    floor, version, theta = key
    return f"Floor {floor:g} {version} {round(theta * 100)}%"


by_student = pd.DataFrame([row for key, plan in solver_runs.items() for row in by_student_rows(key, plan)])
by_course = pd.DataFrame([row for key, plan in solver_runs.items() for row in by_course_rows(key, plan)])
if by_student.empty:
    students_short = pd.DataFrame()
else:
    students_short = by_student[by_student.Shortfall > 1e-9][
        ["Floor", "Version", "Flexibility", "student_id", "Credits listed", "Courses listed",
         "Credits allotted", "Courses allotted", "Shortfall"]]
by_student.head(10)

OUTPUT_DIR.mkdir(exist_ok=True)
workbook = OUTPUT_DIR / "pgp_office_results_v2.xlsx"
with pd.ExcelWriter(workbook) as writer:
    summary.to_excel(writer, sheet_name="Summary", index=False)
    compare.reset_index().to_excel(writer, sheet_name="Heuristic vs solver", index=False)
    courses_asked.to_excel(writer, sheet_name="Courses asked", index=False)
    moved_sessions.to_excel(writer, sheet_name="Moved sessions", index=False)
    by_student.to_excel(writer, sheet_name="By student", index=False)
    by_course.to_excel(writer, sheet_name="By course", index=False)
    students_short.to_excel(writer, sheet_name="Students short", index=False)

matrices = OUTPUT_DIR / "allotment_matrices.xlsx"
with pd.ExcelWriter(matrices) as writer:
    for key, plan in solver_runs.items():
        allotment_matrix(plan).to_excel(writer, sheet_name=sheet_name(key))
heuristic_moved, heuristic_asked = [], []
for key, plan in heuristic_runs.items():
    rows = moved_session_rows(key, plan)
    heuristic_moved += rows
    heuristic_asked += course_asked_rows(key, plan, rows)
heuristic_students = pd.DataFrame([row for key, plan in heuristic_runs.items() for row in by_student_rows(key, plan)])
heuristic_courses = pd.DataFrame([row for key, plan in heuristic_runs.items() for row in by_course_rows(key, plan)])
heuristic_book = OUTPUT_DIR / "heuristic_results.xlsx"
with pd.ExcelWriter(heuristic_book) as writer:
    summary[summary.Method == "Heuristic"].to_excel(writer, sheet_name="Summary", index=False)
    pd.DataFrame(heuristic_asked).to_excel(writer, sheet_name="Courses asked", index=False)
    pd.DataFrame(heuristic_moved).to_excel(writer, sheet_name="Moved sessions", index=False)
    heuristic_students.to_excel(writer, sheet_name="By student", index=False)
    heuristic_courses.to_excel(writer, sheet_name="By course", index=False)
    heuristic_students[heuristic_students.Shortfall > 1e-9][
        ["Floor", "Version", "Flexibility", "student_id", "Credits listed", "Courses listed",
         "Credits allotted", "Courses allotted", "Shortfall"]].to_excel(writer, sheet_name="Students short", index=False)
print("Saved", workbook, matrices, "and", heuristic_book)
